plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.fb3d2y.fbpdf"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.fb3d2y.fbpdf"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // PDFBox para gravar as marcações como anotações reais no PDF.
    dependenciesInfo { includeInApk = false }
}

dependencies {
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
}
