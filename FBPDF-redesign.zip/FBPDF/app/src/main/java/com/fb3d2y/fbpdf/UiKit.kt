package com.fb3d2y.fbpdf

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.min

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density
fun Int.withAlpha(a: Int): Int = (this and 0x00FFFFFF) or ((a and 0xFF) shl 24)

fun roundBg(color: Int, radius: Float, strokeColor: Int = 0, strokeW: Int = 0): GradientDrawable {
    val d = GradientDrawable()
    d.shape = GradientDrawable.RECTANGLE
    d.cornerRadius = radius
    d.setColor(color)
    if (strokeW > 0) d.setStroke(strokeW, strokeColor)
    return d
}

fun ripple(base: Drawable?, rippleColor: Int, radius: Float): RippleDrawable {
    val mask = GradientDrawable()
    mask.setColor(Color.WHITE)
    mask.cornerRadius = radius
    return RippleDrawable(ColorStateList.valueOf(rippleColor), base, mask)
}

/** weight: 0 normal, 1 medium, 2 black */
fun Context.label(s: CharSequence, sizeSp: Float, color: Int, weight: Int = 0): TextView {
    val t = TextView(this)
    t.text = s
    t.textSize = sizeSp
    t.setTextColor(color)
    t.includeFontPadding = false
    t.typeface = when (weight) {
        2 -> Typeface.create("sans-serif-black", Typeface.NORMAL)
        1 -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
        else -> Typeface.create("sans-serif", Typeface.NORMAL)
    }
    return t
}

fun Context.pillButton(pal: Palette, text: String, primary: Boolean, action: () -> Unit): TextView {
    val t = label(text, 14.5f, if (primary) pal.onAccent else pal.ink, 1)
    t.gravity = Gravity.CENTER
    t.background = ripple(
        if (primary) roundBg(pal.accent, dpf(24f)) else roundBg(pal.surfaceHigh, dpf(24f), pal.outline, 1),
        (if (primary) pal.onAccent else pal.ink).withAlpha(30), dpf(24f)
    )
    t.isClickable = true
    t.setOnClickListener { action() }
    return t
}

fun Context.inputField(pal: Palette, hint: String): android.widget.EditText {
    val e = android.widget.EditText(this)
    e.hint = hint
    e.setHintTextColor(pal.muted)
    e.setTextColor(pal.ink)
    e.textSize = 16f
    e.isSingleLine = true
    e.setPadding(dp(16), dp(12), dp(16), dp(12))
    e.background = roundBg(pal.surfaceHigh, dpf(16f), pal.outline, 1)
    return e
}

/** Barra de progresso fina (leitura / cartões). */
class ThinProgress(context: Context, private val track: Int, private val fillColor: Int) : View(context) {
    var rounded = false
    var fraction: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = if (rounded) h / 2f else 0f
        p.color = track
        c.drawRoundRect(0f, 0f, w, h, r, r, p)
        p.color = fillColor
        c.drawRoundRect(0f, 0f, w * fraction, h, r, r, p)
    }
}

/** Ilustração do cartão de boas-vindas: pilha de folhas com marca-texto. */
class HeroView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val sw = w * 0.66f
        val sh = h * 0.86f
        drawSheet(c, w * 0.5f, h * 0.5f, sw, sh, -15f, 0xB3FFFFFF.toInt(), false)
        drawSheet(c, w * 0.5f, h * 0.5f, sw, sh, 8f, 0xE0FFFFFF.toInt(), false)
        drawSheet(c, w * 0.5f, h * 0.5f, sw, sh, -2f, 0xFFFFFFFF.toInt(), true)
    }

    private fun drawSheet(c: Canvas, cx: Float, cy: Float, sw: Float, sh: Float, rot: Float, color: Int, detailed: Boolean) {
        val r = context.dpf(10f)
        val l = cx - sw / 2f
        val t = cy - sh / 2f
        c.save()
        c.rotate(rot, cx, cy)
        p.color = 0x24000000
        c.drawRoundRect(l, t + context.dpf(3f), l + sw, t + sh + context.dpf(3f), r, r, p)
        p.color = color
        c.drawRoundRect(l, t, l + sw, t + sh, r, r, p)
        if (detailed) {
            val pad = sw * 0.14f
            val lineH = sh * 0.034f
            p.color = 0xFF1A1D24.toInt()
            c.drawRoundRect(l + pad, t + sh * 0.13f, l + sw * 0.62f, t + sh * 0.13f + lineH * 1.5f, lineH, lineH, p)
            for (i in 0 until 7) {
                val y = t + sh * (0.28f + i * 0.085f)
                if (i == 2 || i == 3) {
                    p.color = 0xCCFFD43B.toInt()
                    c.drawRoundRect(l + pad - 4f, y - lineH * 0.7f, l + sw - pad + 4f, y + lineH * 1.7f, lineH, lineH, p)
                }
                p.color = 0x4D1A1D24
                val end = if (i % 3 == 2) 0.62f else 0.86f
                c.drawRoundRect(l + pad, y, l + sw * end, y + lineH, lineH / 2f, lineH / 2f, p)
            }
        }
        c.restore()
    }
}

class MaxHeightScroll(context: Context, private val maxH: Int) : ScrollView(context) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
    }
}

/** Bottom sheet com cantos arredondados, no lugar dos AlertDialog padrão. */
class Sheet(private val act: Activity, private val pal: Palette, bottomInset: Int) {
    private val dialog = Dialog(act)
    private val panel = LinearLayout(act)
    private val head = LinearLayout(act)
    private val list = LinearLayout(act)
    private val scroll: MaxHeightScroll

    init {
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        panel.orientation = LinearLayout.VERTICAL
        val r = act.dpf(28f)
        val bg = GradientDrawable()
        bg.setColor(pal.surface)
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        panel.background = bg
        val extra = if (Build.VERSION.SDK_INT >= 35) bottomInset else 0
        panel.setPadding(act.dp(20), act.dp(10), act.dp(20), act.dp(18) + extra)

        val handle = View(act)
        handle.background = roundBg(pal.outline, act.dpf(2f))
        val hlp = LinearLayout.LayoutParams(act.dp(40), act.dp(4))
        hlp.gravity = Gravity.CENTER_HORIZONTAL
        hlp.bottomMargin = act.dp(16)
        panel.addView(handle, hlp)

        head.orientation = LinearLayout.VERTICAL
        panel.addView(head, LinearLayout.LayoutParams(-1, -2))

        list.orientation = LinearLayout.VERTICAL
        val maxH = (act.resources.displayMetrics.heightPixels * 0.66f).toInt()
        scroll = MaxHeightScroll(act, maxH)
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(list, ViewGroup.LayoutParams(-1, -2))
        panel.addView(scroll, LinearLayout.LayoutParams(-1, -2))

        dialog.setContentView(panel)
        val w = dialog.window
        if (w != null) {
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            w.setGravity(Gravity.BOTTOM)
            w.setDimAmount(0.6f)
        }
        dialog.setCanceledOnTouchOutside(true)
    }

    fun title(t: String, sub: String? = null): Sheet {
        head.addView(act.label(t, 21f, pal.ink, 1))
        if (sub != null) {
            val s = act.label(sub, 13.5f, pal.muted, 0)
            s.setPadding(0, act.dp(6), 0, 0)
            s.setLineSpacing(0f, 1.1f)
            head.addView(s)
        }
        val gap = View(act)
        head.addView(gap, LinearLayout.LayoutParams(1, act.dp(14)))
        return this
    }

    /** Fixo, acima da área rolável (campos de busca, grade…). */
    fun top(v: View, lp: LinearLayout.LayoutParams? = null): Sheet {
        head.addView(v, lp ?: LinearLayout.LayoutParams(-1, -2))
        return this
    }

    fun add(v: View, lp: LinearLayout.LayoutParams? = null): Sheet {
        list.addView(v, lp ?: LinearLayout.LayoutParams(-1, -2))
        return this
    }

    /** Fixo, abaixo do conteúdo (botões). */
    fun bottom(v: View, lp: LinearLayout.LayoutParams? = null): Sheet {
        val l = lp ?: LinearLayout.LayoutParams(-1, -2)
        panel.addView(v, l)
        return this
    }

    fun row(icon: String, text: String, trailing: String? = null, selected: Boolean = false, action: () -> Unit): Sheet {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(act.dp(8), 0, act.dp(10), 0)
        row.background = ripple(null, pal.ink.withAlpha(26), act.dpf(16f))
        row.isClickable = true
        row.setOnClickListener {
            dismiss()
            action()
        }
        val ic = IconView(act, icon, if (selected) pal.accentInk else pal.muted)
        row.addView(ic, LinearLayout.LayoutParams(act.dp(40), act.dp(40)))
        val tv = act.label(text, 15.5f, pal.ink, if (selected) 1 else 0)
        val tlp = LinearLayout.LayoutParams(0, -2, 1f)
        tlp.marginStart = act.dp(6)
        row.addView(tv, tlp)
        if (selected) {
            row.addView(IconView(act, "check", pal.accentInk), LinearLayout.LayoutParams(act.dp(28), act.dp(28)))
        } else if (trailing != null) {
            row.addView(act.label(trailing, 13f, pal.muted, 0))
        }
        list.addView(row, LinearLayout.LayoutParams(-1, act.dp(52)))
        return this
    }

    fun isShowing(): Boolean = dialog.isShowing

    fun setOnDismiss(action: () -> Unit): Sheet {
        dialog.setOnDismissListener { action() }
        return this
    }

    fun show(keyboard: Boolean = false) {
        val w = dialog.window
        if (w != null) {
            var mode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            if (keyboard) mode = mode or WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
            w.setSoftInputMode(mode)
        }
        panel.alpha = 0f
        panel.translationY = act.dp(56).toFloat()
        dialog.show()
        panel.animate().alpha(1f).translationY(0f).setDuration(240).setInterpolator(DecelerateInterpolator(1.6f)).start()
    }

    fun dismiss() {
        try {
            dialog.dismiss()
        } catch (_: Exception) {
        }
    }
}
