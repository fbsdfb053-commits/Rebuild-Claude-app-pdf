package com.fb3d2y.fbpdf

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class PdfTextBox(val left: Float, val top: Float, val right: Float, val bottom: Float)

data class PdfHighlight(
    val page: Int,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    val color: Int,
    val group: Int = 0
)

/**
 * Página do PDF: zoom por pinça e duplo toque, arraste, troca de página por deslize,
 * toques nas bordas, seleção de texto contínua (várias linhas) e borracha por toque.
 */
class PdfPageView(context: Context) : View(context) {
    /** -1 borda esquerda, 0 centro, 1 borda direita */
    var onTapZone: ((Int) -> Unit)? = null

    /** 1 = próxima página, -1 = anterior */
    var onSwipe: ((Int) -> Unit)? = null
    var onMarksChanged: (() -> Unit)? = null

    private var bitmap: Bitmap? = null
    private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val markPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }
    private val multiply = PorterDuffXfermode(PorterDuff.Mode.MULTIPLY)
    private val rect = RectF()
    private val tmp = RectF()
    private val marks = ArrayList<PdfHighlight>()
    private val preview = ArrayList<RectF>()
    private var textBoxes: List<PdfTextBox> = emptyList()
    private var pageIndex = 0

    private var markMode = false
    private var eraseMode = false
    private var highlightColor = Color.rgb(255, 228, 92)
    private var night = false
    private var dark = true
    private var groupSeq = 0

    private var selecting = false
    private var selA = -1
    private var selB = -1
    private val start = PointF()
    private val end = PointF()

    private var zoom = 1f
    private var offsetX = 0f
    private var offsetY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var multi = false
    private var dragging = false
    private var pendingTap = false
    private var zoomAnim: ValueAnimator? = null

    private val margin = context.dpf(14f)
    private var insetTop = 0f
    private var insetBottom = 0f
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    private val tapRunnable = Runnable {
        pendingTap = false
        onTapZone?.invoke(0)
    }

    private val detector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            zoomAnim?.cancel()
            val old = zoom
            zoom = (zoom * d.scaleFactor).coerceIn(1f, 5f)
            val f = zoom / old
            offsetX = d.focusX - (d.focusX - offsetX) * f
            offsetY = d.focusY - (d.focusY - offsetY) * f
            clampOffsets()
            invalidate()
            return true
        }
    })

    // ---------- API ----------

    fun applyPalette(p: Palette) {
        dark = p.dark
        borderPaint.color = p.outline
        invalidate()
    }

    fun setMarkMode(enabled: Boolean) {
        markMode = enabled
        if (enabled) eraseMode = false
        cancelSelection()
    }

    fun setEraseMode(enabled: Boolean) {
        eraseMode = enabled
        if (enabled) markMode = false
        cancelSelection()
    }

    fun setHighlightColor(color: Int) {
        highlightColor = color
        invalidate()
    }

    /** Inverte as cores da página (leitura noturna), mantendo um branco/preto suaves. */
    fun setNightPage(on: Boolean) {
        night = on
        imagePaint.colorFilter = if (on) ColorMatrixColorFilter(ColorMatrix(NIGHT)) else null
        invalidate()
    }

    fun setInsets(top: Int, bottom: Int) {
        insetTop = top.toFloat()
        insetBottom = bottom.toFloat()
        clampOffsets()
        invalidate()
    }

    fun currentInsetTop(): Int = insetTop.toInt()
    fun currentInsetBottom(): Int = insetBottom.toInt()

    fun getHighlights(): List<PdfHighlight> = marks.toList()

    fun setMarks(list: List<PdfHighlight>) {
        marks.clear()
        marks.addAll(list)
        for (m in list) groupSeq = max(groupSeq, m.group)
        onMarksChanged?.invoke()
        invalidate()
    }
    fun hasMarks(): Boolean = marks.isNotEmpty()

    fun setPage(page: Bitmap, index: Int, boxes: List<PdfTextBox>) {
        bitmap?.recycle()
        bitmap = page
        pageIndex = index
        textBoxes = boxes
        zoomAnim?.cancel()
        zoom = 1f
        cancelSelection()
        clampOffsets()
        invalidate()
    }

    fun setTextBoxes(boxes: List<PdfTextBox>) {
        textBoxes = boxes
    }

    fun clearPage() {
        zoomAnim?.cancel()
        bitmap?.recycle()
        bitmap = null
        marks.clear()
        preview.clear()
        textBoxes = emptyList()
        invalidate()
    }

    /** A página inteira em alta resolução, com os destaques desenhados por cima. */
    fun exportPageImage(): Bitmap? {
        val src = bitmap ?: return null
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(src, 0f, 0f, imagePaint)
        for (m in marks) {
            if (m.page == pageIndex) drawRectMark(c, m.left, m.top, m.right, m.bottom, m.color, src.width.toFloat(), src.height.toFloat(), 1f)
        }
        return out
    }

    fun saveMarks(b: Bundle) {
        val n = marks.size
        val pages = IntArray(n)
        val colors = IntArray(n)
        val groups = IntArray(n)
        val rects = FloatArray(n * 4)
        for (i in 0 until n) {
            val m = marks[i]
            pages[i] = m.page
            colors[i] = m.color
            groups[i] = m.group
            rects[i * 4] = m.left
            rects[i * 4 + 1] = m.top
            rects[i * 4 + 2] = m.right
            rects[i * 4 + 3] = m.bottom
        }
        b.putIntArray("mk_pages", pages)
        b.putIntArray("mk_colors", colors)
        b.putIntArray("mk_groups", groups)
        b.putFloatArray("mk_rects", rects)
    }

    fun restoreMarks(b: Bundle) {
        val pages = b.getIntArray("mk_pages") ?: return
        val colors = b.getIntArray("mk_colors") ?: return
        val groups = b.getIntArray("mk_groups") ?: return
        val rects = b.getFloatArray("mk_rects") ?: return
        if (rects.size < pages.size * 4) return
        marks.clear()
        for (i in pages.indices) {
            marks.add(PdfHighlight(pages[i], rects[i * 4], rects[i * 4 + 1], rects[i * 4 + 2], rects[i * 4 + 3], colors[i], groups[i]))
            groupSeq = max(groupSeq, groups[i])
        }
        onMarksChanged?.invoke()
        invalidate()
    }

    // ---------- Desenho ----------

    private fun availW(): Float = max(1f, width - 2f * margin)
    private fun availH(): Float = max(1f, height - insetTop - insetBottom)

    private fun place(extent: Float, avail: Float, startPos: Float, total: Float, current: Float): Float {
        if (extent <= avail) return startPos + (avail - extent) / 2f
        if (total > avail && extent <= total) {
            val t = (extent - avail) / (total - avail)
            val b = (total - extent) / 2f
            return startPos + (b - startPos) * t
        }
        return current.coerceIn(total - extent, 0f)
    }

    private fun clampOffsets() {
        val image = bitmap ?: return
        if (width == 0 || height == 0) return
        val aw = availW()
        val ah = availH()
        val fit = min(aw / image.width, ah / image.height)
        val w = image.width * fit * zoom
        val h = image.height * fit * zoom
        offsetX = place(w, aw, margin, width.toFloat(), offsetX)
        offsetY = place(h, ah, insetTop, height.toFloat(), offsetY)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        clampOffsets()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val image = bitmap ?: return
        clampOffsets()
        val fit = min(availW() / image.width, availH() / image.height)
        val w = image.width * fit * zoom
        val h = image.height * fit * zoom
        rect.set(offsetX, offsetY, offsetX + w, offsetY + h)

        // sombra suave em camadas
        val d = context.dpf(2.2f)
        for (i in 1..5) {
            shadowPaint.color = Color.BLACK
            shadowPaint.alpha = if (dark) 44 - i * 7 else 30 - i * 5
            val g = i * d
            tmp.set(rect.left - g, rect.top - g + d * 1.6f, rect.right + g, rect.bottom + g + d * 1.6f)
            canvas.drawRoundRect(tmp, g + 4f, g + 4f, shadowPaint)
        }
        canvas.drawBitmap(image, null, rect, imagePaint)
        canvas.drawRect(rect, borderPaint)

        val save = canvas.save()
        canvas.clipRect(rect)
        canvas.translate(rect.left, rect.top)
        canvas.scale(rect.width() / image.width, rect.height() / image.height)
        val iw = image.width.toFloat()
        val ih = image.height.toFloat()
        for (m in marks) {
            if (m.page == pageIndex) drawRectMark(canvas, m.left, m.top, m.right, m.bottom, m.color, iw, ih, 1f)
        }
        if (selecting) {
            if (textBoxes.isNotEmpty()) {
                for (r in preview) drawRectMark(canvas, r.left, r.top, r.right, r.bottom, highlightColor, iw, ih, 0.75f)
            } else {
                drawRectMark(canvas, min(start.x, end.x), min(start.y, end.y), max(start.x, end.x), max(start.y, end.y), highlightColor, iw, ih, 0.6f)
            }
        }
        canvas.restoreToCount(save)
    }

    private fun drawRectMark(c: Canvas, l: Float, t: Float, r: Float, b: Float, color: Int, w: Float, h: Float, strength: Float) {
        markPaint.color = color
        if (night) {
            markPaint.xfermode = null
            markPaint.alpha = (96 * strength).toInt()
        } else {
            markPaint.xfermode = multiply
            markPaint.alpha = (238 * strength).toInt()
        }
        tmp.set(l * w - 1.5f, t * h, r * w + 1.5f, b * h)
        c.drawRoundRect(tmp, 3f, 3f, markPaint)
        markPaint.xfermode = null
    }

    // ---------- Seleção ----------

    private fun screenToPage(x: Float, y: Float): PointF? {
        if (!rect.contains(x, y)) return null
        return PointF(((x - rect.left) / rect.width()).coerceIn(0f, 1f), ((y - rect.top) / rect.height()).coerceIn(0f, 1f))
    }

    private fun nearestBox(p: PointF): Int {
        var best = -1
        var bestD = Float.MAX_VALUE
        for (i in textBoxes.indices) {
            val t = textBoxes[i]
            val dx = if (p.x < t.left) t.left - p.x else if (p.x > t.right) p.x - t.right else 0f
            val dy = if (p.y < t.top) t.top - p.y else if (p.y > t.bottom) p.y - t.bottom else 0f
            val dd = dx * dx + dy * dy
            if (dd < bestD) {
                bestD = dd
                best = i
                if (dd == 0f) break
            }
        }
        return if (bestD <= 0.0064f) best else -1
    }

    /** Une letras consecutivas da mesma linha em retângulos únicos. */
    private fun mergeBoxes(a: Int, b: Int): List<RectF> {
        val out = ArrayList<RectF>()
        val lo = min(a, b)
        val hi = max(a, b)
        var cur: RectF? = null
        for (i in lo..hi) {
            if (i < 0 || i >= textBoxes.size) continue
            val t = textBoxes[i]
            val c = cur
            if (c == null) {
                cur = RectF(t.left, t.top, t.right, t.bottom)
                continue
            }
            val cy = (c.top + c.bottom) / 2f
            val ty = (t.top + t.bottom) / 2f
            val hh = max(c.bottom - c.top, t.bottom - t.top)
            if (abs(cy - ty) < hh * 0.6f && t.left >= c.left - 0.01f) {
                c.left = min(c.left, t.left)
                c.top = min(c.top, t.top)
                c.right = max(c.right, t.right)
                c.bottom = max(c.bottom, t.bottom)
            } else {
                out.add(c)
                cur = RectF(t.left, t.top, t.right, t.bottom)
            }
        }
        val last = cur
        if (last != null) out.add(last)
        return out
    }

    private fun updatePreview() {
        preview.clear()
        if (textBoxes.isNotEmpty() && selA >= 0 && selB >= 0) preview.addAll(mergeBoxes(selA, selB))
    }

    private fun cancelSelection() {
        selecting = false
        selA = -1
        selB = -1
        preview.clear()
        invalidate()
    }

    private fun commitSelection() {
        val g = ++groupSeq
        var added = false
        if (textBoxes.isNotEmpty()) {
            if (selA >= 0 && selB >= 0 && selA != selB) {
                for (r in preview) {
                    marks.add(PdfHighlight(pageIndex, r.left, r.top, r.right, r.bottom, highlightColor, g))
                    added = true
                }
            }
        } else {
            val l = min(start.x, end.x)
            val r = max(start.x, end.x)
            val t = min(start.y, end.y)
            val b = max(start.y, end.y)
            if (r - l > 0.01f && b - t > 0.004f) {
                marks.add(PdfHighlight(pageIndex, l, t, r, b, highlightColor, g))
                added = true
            }
        }
        preview.clear()
        selA = -1
        selB = -1
        if (added) {
            performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
            onMarksChanged?.invoke()
        }
    }

    private fun eraseAt(p: PointF) {
        val radius = 0.016f
        val hit = HashSet<Int>()
        for (m in marks) {
            if (m.page != pageIndex) continue
            val nx = p.x.coerceIn(m.left, m.right)
            val ny = p.y.coerceIn(m.top, m.bottom)
            val dx = p.x - nx
            val dy = p.y - ny
            if (dx * dx + dy * dy <= radius * radius) hit.add(m.group)
        }
        if (hit.isNotEmpty()) {
            marks.removeAll { it.group in hit }
            performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
            onMarksChanged?.invoke()
            invalidate()
        }
    }

    // ---------- Gestos ----------

    private fun animateZoom(target: Float, fx: Float, fy: Float) {
        zoomAnim?.cancel()
        val anim = ValueAnimator.ofFloat(zoom, target)
        anim.duration = 240
        anim.interpolator = DecelerateInterpolator()
        anim.addUpdateListener { a ->
            val old = zoom
            zoom = a.animatedValue as Float
            val f = zoom / old
            offsetX = fx - (fx - offsetX) * f
            offsetY = fy - (fy - offsetY) * f
            clampOffsets()
            invalidate()
        }
        zoomAnim = anim
        anim.start()
    }

    private fun handleTap(x: Float, y: Float) {
        val zone = if (zoom > 1.05f) 0 else if (x < width * 0.2f) -1 else if (x > width * 0.8f) 1 else 0
        if (zone != 0) {
            removeCallbacks(tapRunnable)
            pendingTap = false
            onTapZone?.invoke(zone)
            return
        }
        if (pendingTap) {
            removeCallbacks(tapRunnable)
            pendingTap = false
            animateZoom(if (zoom > 1.2f) 1f else 2.4f, x, y)
        } else {
            pendingTap = true
            postDelayed(tapRunnable, ViewConfiguration.getDoubleTapTimeout().toLong())
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            multi = false
            downX = e.x
            downY = e.y
            downTime = e.eventTime
        }
        if ((markMode || eraseMode) && e.pointerCount == 1 && !multi) {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val p = screenToPage(e.x, e.y) ?: return true
                    start.set(p)
                    end.set(p)
                    if (eraseMode) {
                        eraseAt(p)
                    } else {
                        selecting = true
                        selA = nearestBox(p)
                        selB = selA
                        updatePreview()
                        invalidate()
                    }
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val p = screenToPage(e.x, e.y)
                    if (p != null) {
                        end.set(p)
                        if (eraseMode) {
                            eraseAt(p)
                        } else if (selecting) {
                            selB = nearestBox(p)
                            if (selA < 0) selA = selB
                            updatePreview()
                            invalidate()
                        }
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (selecting) commitSelection()
                    selecting = false
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_CANCEL -> {
                    cancelSelection()
                    return true
                }
            }
        }
        if (selecting) cancelSelection()

        detector.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x
                lastY = e.y
                dragging = true
            }
            MotionEvent.ACTION_POINTER_DOWN -> multi = true
            MotionEvent.ACTION_POINTER_UP -> {
                val idx = if (e.actionIndex == 0) 1 else 0
                if (idx < e.pointerCount) {
                    lastX = e.getX(idx)
                    lastY = e.getY(idx)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging && !detector.isInProgress && e.pointerCount == 1 && zoom > 1f) {
                    offsetX += e.x - lastX
                    offsetY += e.y - lastY
                    clampOffsets()
                    invalidate()
                }
                lastX = e.x
                lastY = e.y
            }
            MotionEvent.ACTION_UP -> {
                dragging = false
                if (!multi && !detector.isInProgress) {
                    val dx = e.x - downX
                    val dy = e.y - downY
                    val dt = e.eventTime - downTime
                    if (abs(dx) < slop && abs(dy) < slop && dt < 350) {
                        handleTap(e.x, e.y)
                    } else if (zoom <= 1.05f && abs(dx) > context.dp(64) && abs(dx) > abs(dy) * 1.6f) {
                        onSwipe?.invoke(if (dx < 0) 1 else -1)
                    }
                }
            }
            MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return true
    }

    companion object {
        // inverte a página: branco -> #141416, preto -> off-white quente
        private val NIGHT = floatArrayOf(
            -0.847f, 0f, 0f, 0f, 236f,
            0f, -0.831f, 0f, 0f, 232f,
            0f, 0f, -0.792f, 0f, 224f,
            0f, 0f, 0f, 1f, 0f
        )
    }
}
