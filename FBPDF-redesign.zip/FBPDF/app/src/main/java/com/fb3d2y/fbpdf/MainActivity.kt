package com.fb3d2y.fbpdf

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.TextUtils
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.util.LruCache
import android.animation.ValueAnimator
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowInsets
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDColor
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDDeviceRGB
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationTextMarkup
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.File
import java.io.IOException
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

private class SearchHit(val page: Int, val snippet: String, val start: Int, val len: Int, val count: Int)

class MainActivity : Activity() {
    private lateinit var pal: Palette
    private lateinit var prefs: SharedPreferences
    private lateinit var recents: RecentStore

    // views
    private lateinit var root: FrameLayout
    private lateinit var pageView: PdfPageView
    private lateinit var topBar: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var subtitleView: TextView
    private lateinit var readProgress: ThinProgress
    private lateinit var bottomStack: LinearLayout
    private lateinit var palette: LinearLayout
    private lateinit var scrubLabel: TextView
    private lateinit var slider: SeekBar
    private lateinit var penButton: IconView
    private lateinit var eraserButton: IconView
    private lateinit var bookmarkButton: IconView
    private lateinit var saveButton: IconView
    private lateinit var homeScroll: ScrollView
    private lateinit var homeList: LinearLayout
    private val swatches = ArrayList<Pair<View, Int>>()

    // estado do documento
    private val renderLock = Any()
    private var descriptor: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null
    private var currentUri: Uri? = null
    private var currentName = ""
    private var currentPage = 0
    private var pageCount = 0
    private var docGen = 0
    private val textBoxes = HashMap<Int, List<PdfTextBox>>()

    // estado da interface
    private var insetTop = 0
    private var insetBottom = 0
    private var chromeVisible = true
    private var tool = TOOL_NONE
    private var markColor = Themes.highlightColors[0]
    private var nightPage = false
    private var penHintShown = false
    private var lastScrubRender = 0L
    private var insetAnim: ValueAnimator? = null
    private var pendingScreenshot: Bitmap? = null
    private var pendingSaveHighlights: List<PdfHighlight> = emptyList()
    @Volatile
    private var searchGen = 0

    private val textExec = Executors.newSingleThreadExecutor()
    private val thumbExec = Executors.newSingleThreadExecutor()
    private val thumbPending = HashSet<Int>()
    private val thumbCache: LruCache<Int, Bitmap> = object : LruCache<Int, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
    }

    // ------------------------------------------------------------------ ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = getSharedPreferences("fbpdf_ui", MODE_PRIVATE)
        pal = resolvePalette()
        setTheme(if (pal.dark) R.style.Theme_FBPDF_Dark else R.style.Theme_FBPDF_Light)
        super.onCreate(savedInstanceState)
        recents = RecentStore(this)
        nightPage = prefs.getBoolean("night_page", false)
        PDFBoxResourceLoader.init(applicationContext)
        setupWindow()
        buildScreen()
        showHome(false)
        if (savedInstanceState != null && savedInstanceState.containsKey("uri")) {
            val uri = Uri.parse(savedInstanceState.getString("uri"))
            openPdf(uri, savedInstanceState.getInt("page", 0), savedInstanceState)
        } else {
            handleIncomingIntent(intent)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        val u = currentUri ?: return
        outState.putString("uri", u.toString())
        outState.putInt("page", currentPage)
        pageView.saveMarks(outState)
    }

    override fun onPause() {
        persistRecent()
        super.onPause()
    }

    override fun onDestroy() {
        closePdf()
        textExec.shutdownNow()
        thumbExec.shutdownNow()
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (currentUri != null && homeScroll.visibility != View.VISIBLE) {
            if (tool != TOOL_NONE) setTool(TOOL_NONE) else closeToHome()
        } else {
            super.onBackPressed()
        }
    }

    private fun resolvePalette(): Palette {
        val mode = prefs.getInt("theme", 2) // 0 automático, 1 claro, 2 noite
        val sysNight = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        return if (mode == 2 || (mode == 0 && sysNight)) Themes.night else Themes.day
    }

    @Suppress("DEPRECATION")
    private fun setupWindow() {
        val w = window
        w.setBackgroundDrawable(ColorDrawable(pal.bg))
        w.statusBarColor = Color.TRANSPARENT
        w.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) w.isNavigationBarContrastEnforced = false
        var flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        if (!pal.dark) {
            flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        w.decorView.systemUiVisibility = flags
    }

    private fun handleIncomingIntent(incoming: Intent?) {
        when (incoming?.action) {
            Intent.ACTION_VIEW -> incoming.data?.let { uri ->
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
                openPdf(uri)
            }
            Intent.ACTION_SEND -> {
                val uri = if (Build.VERSION.SDK_INT >= 33) incoming.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else @Suppress("DEPRECATION") incoming.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri
                if (uri != null) openPdf(uri)
            }
        }
    }

    // ------------------------------------------------------------------ construção da interface

    private fun lp(w: Int, h: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h)

    private fun iconBtn(name: String, desc: String, action: () -> Unit): IconView {
        val v = IconView(this, name, pal.ink, pal.accent, pal.onAccent, pal.accent)
        v.contentDescription = desc
        v.isClickable = true
        v.isFocusable = true
        v.background = ripple(null, pal.ink.withAlpha(30), dpf(26f))
        v.setOnClickListener { action() }
        return v
    }

    private fun buildScreen() {
        root = FrameLayout(this)
        root.setBackgroundColor(pal.bg)
        root.setOnApplyWindowInsetsListener { _, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val b = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                insetTop = b.top
                insetBottom = b.bottom
            } else {
                @Suppress("DEPRECATION")
                insetTop = insets.systemWindowInsetTop
                @Suppress("DEPRECATION")
                insetBottom = insets.systemWindowInsetBottom
            }
            applyInsets()
            insets
        }

        // página
        pageView = PdfPageView(this)
        pageView.applyPalette(pal)
        pageView.setNightPage(nightPage)
        pageView.setHighlightColor(markColor)
        pageView.onSwipe = { dir -> showPage(currentPage + dir, dir) }
        pageView.onTapZone = { zone ->
            if (zone == 0) setChrome(!chromeVisible) else showPage(currentPage + zone, zone)
        }
        pageView.onMarksChanged = { saveButton.badge = pageView.hasMarks() }
        root.addView(pageView, FrameLayout.LayoutParams(-1, -1))

        buildTopBar()
        buildBottomStack()
        buildHomeShell()
        setContentView(root)
        root.requestApplyInsets()
    }

    private fun buildTopBar() {
        topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.VERTICAL
        topBar.setBackgroundColor(pal.surface.withAlpha(0xF2))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(6), 0, dp(6), 0)
        row.addView(iconBtn("back", "Voltar à biblioteca") { closeToHome() }, lp(dp(46), dp(46)))

        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.gravity = Gravity.CENTER_VERTICAL
        titles.setPadding(dp(4), 0, dp(6), 0)
        titleView = label("", 15f, pal.ink, 1)
        titleView.maxLines = 1
        titleView.ellipsize = TextUtils.TruncateAt.END
        subtitleView = label("", 11.5f, pal.muted, 0)
        subtitleView.setPadding(0, dp(3), 0, 0)
        titles.addView(titleView)
        titles.addView(subtitleView)
        row.addView(titles, LinearLayout.LayoutParams(0, dp(56), 1f))

        row.addView(iconBtn("search", "Buscar no PDF") { openSearchSheet() }, lp(dp(44), dp(46)))
        row.addView(iconBtn("grid", "Miniaturas das páginas") { openThumbs() }, lp(dp(44), dp(46)))
        row.addView(iconBtn("more", "Mais opções") { openMenu() }, lp(dp(44), dp(46)))
        topBar.addView(row, lp(-1, dp(56)))

        readProgress = ThinProgress(this, pal.outline, pal.accent)
        topBar.addView(readProgress, lp(-1, dp(2)))
        root.addView(topBar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        topBar.visibility = View.GONE
    }

    private fun buildBottomStack() {
        bottomStack = LinearLayout(this)
        bottomStack.orientation = LinearLayout.VERTICAL
        bottomStack.gravity = Gravity.CENTER_HORIZONTAL

        // paleta de cores (aparece com o marca-texto)
        palette = LinearLayout(this)
        palette.orientation = LinearLayout.HORIZONTAL
        palette.gravity = Gravity.CENTER
        palette.setPadding(dp(8), dp(8), dp(8), dp(8))
        palette.background = roundBg(pal.surface.withAlpha(0xF8), dpf(26f), pal.outline, 1)
        palette.elevation = dpf(8f)
        palette.visibility = View.GONE
        for (color in Themes.highlightColors) {
            val sw = View(this)
            sw.contentDescription = "Cor do marca-texto"
            sw.setOnClickListener { selectColor(color) }
            val slp = lp(dp(28), dp(28))
            slp.marginStart = dp(5)
            slp.marginEnd = dp(5)
            palette.addView(sw, slp)
            swatches.add(Pair(sw, color))
        }
        selectColor(markColor)
        val plp = lp(-2, -2)
        plp.bottomMargin = dp(10)
        bottomStack.addView(palette, plp)

        // controle de páginas
        val scrub = LinearLayout(this)
        scrub.orientation = LinearLayout.HORIZONTAL
        scrub.gravity = Gravity.CENTER_VERTICAL
        scrub.setPadding(dp(18), 0, dp(12), 0)
        scrub.background = roundBg(pal.surface.withAlpha(0xF5), dpf(23f), pal.outline, 1)
        scrub.elevation = dpf(6f)
        scrubLabel = label("", 13f, pal.ink, 1)
        scrubLabel.minWidth = dp(54)
        scrubLabel.setOnClickListener { openJumpSheet() }
        scrub.addView(scrubLabel)
        slider = SeekBar(this)
        slider.max = 0
        slider.progressTintList = android.content.res.ColorStateList.valueOf(pal.accent)
        slider.progressBackgroundTintList = android.content.res.ColorStateList.valueOf(pal.outline)
        slider.thumbTintList = android.content.res.ColorStateList.valueOf(pal.accent)
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                scrubLabel.text = "${progress + 1} / $pageCount"
                val now = SystemClock.uptimeMillis()
                if (now - lastScrubRender > 110) {
                    lastScrubRender = now
                    showPage(progress)
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                if (sb != null) showPage(sb.progress)
            }
        })
        scrub.addView(slider, lp(0, -1).also { it.weight = 1f })
        val slp = lp(-1, dp(SCRUB_H))
        slp.bottomMargin = dp(GAP)
        bottomStack.addView(scrub, slp)

        // dock de ferramentas
        val dock = LinearLayout(this)
        dock.orientation = LinearLayout.HORIZONTAL
        dock.gravity = Gravity.CENTER_VERTICAL
        dock.setPadding(dp(6), 0, dp(6), 0)
        dock.background = roundBg(pal.surface.withAlpha(0xF5), dpf(30f), pal.outline, 1)
        dock.elevation = dpf(10f)
        penButton = iconBtn("pen", "Marca-texto") { toggleTool(TOOL_PEN) }
        eraserButton = iconBtn("eraser", "Borracha de marcações") { toggleTool(TOOL_ERASER) }
        bookmarkButton = iconBtn("bookmark", "Favoritar página") { toggleBookmark() }
        saveButton = iconBtn("save", "Salvar marcações no PDF") { saveMarkedPdf() }
        val shotButton = iconBtn("camera", "Capturar página") { captureScreenshot() }
        val shareButton = iconBtn("share", "Compartilhar PDF") { sharePdf() }
        for (b in listOf(penButton, eraserButton, bookmarkButton, saveButton, shotButton, shareButton)) {
            dock.addView(b, LinearLayout.LayoutParams(0, dp(52), 1f))
        }
        bottomStack.addView(dock, lp(-1, dp(DOCK_H)))

        val flp = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM)
        flp.marginStart = dp(12)
        flp.marginEnd = dp(12)
        flp.bottomMargin = dp(12)
        root.addView(bottomStack, flp)
        bottomStack.visibility = View.GONE
    }

    private fun buildHomeShell() {
        homeScroll = ScrollView(this)
        homeScroll.setBackgroundColor(pal.bg)
        homeScroll.isVerticalScrollBarEnabled = false
        homeScroll.overScrollMode = View.OVER_SCROLL_NEVER
        homeList = LinearLayout(this)
        homeList.orientation = LinearLayout.VERTICAL
        homeScroll.addView(homeList, ViewGroup.LayoutParams(-1, -2))
        root.addView(homeScroll, FrameLayout.LayoutParams(-1, -1))
    }

    private fun applyInsets() {
        topBar.setPadding(0, insetTop, 0, 0)
        val flp = bottomStack.layoutParams as FrameLayout.LayoutParams
        flp.bottomMargin = insetBottom + dp(12)
        bottomStack.layoutParams = flp
        homeList.setPadding(dp(20), insetTop + dp(18), dp(20), insetBottom + dp(36))
        updatePageInsets(false)
    }

    private fun topBarHeight(): Int = insetTop + dp(58)

    private fun updatePageInsets(animate: Boolean) {
        val tt = if (chromeVisible) topBarHeight() + dp(10) else insetTop + dp(10)
        val tb = if (chromeVisible) insetBottom + dp(12 + DOCK_H + GAP + SCRUB_H + 12) else insetBottom + dp(10)
        insetAnim?.cancel()
        if (!animate) {
            pageView.setInsets(tt, tb)
            return
        }
        val ft = pageView.currentInsetTop()
        val fb = pageView.currentInsetBottom()
        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.duration = 240
        anim.interpolator = DecelerateInterpolator()
        anim.addUpdateListener { a ->
            val f = a.animatedValue as Float
            pageView.setInsets((ft + (tt - ft) * f).toInt(), (fb + (tb - fb) * f).toInt())
        }
        insetAnim = anim
        anim.start()
    }

    private fun setChrome(show: Boolean) {
        if (show == chromeVisible || currentUri == null) return
        chromeVisible = show
        if (show) {
            topBar.visibility = View.VISIBLE
            bottomStack.visibility = View.VISIBLE
        }
        topBar.animate().alpha(if (show) 1f else 0f).translationY(if (show) 0f else -topBar.height.toFloat())
            .setDuration(230).withEndAction { if (!chromeVisible) topBar.visibility = View.INVISIBLE }.start()
        bottomStack.animate().alpha(if (show) 1f else 0f).translationY(if (show) 0f else (bottomStack.height + dp(30)).toFloat())
            .setDuration(230).withEndAction { if (!chromeVisible) bottomStack.visibility = View.INVISIBLE }.start()
        updatePageInsets(true)
    }

    // ------------------------------------------------------------------ biblioteca (tela inicial)

    private fun buildHome() {
        homeList.removeAllViews()

        // cabeçalho
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val word = SpannableString("FBPDF")
        word.setSpan(ForegroundColorSpan(pal.accentInk), 2, 5, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val brand = label(word, 24f, pal.ink, 2)
        brand.letterSpacing = 0.05f
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val settings = iconBtn(if (pal.dark) "moon" else "sun", "Aparência") { openAppearanceSheet() }
        header.addView(settings, lp(dp(46), dp(46)))
        homeList.addView(header, lp(-1, dp(48)))

        // cartão principal
        val hero = LinearLayout(this)
        hero.orientation = LinearLayout.HORIZONTAL
        val heroBg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFFFFC857.toInt(), 0xFFFF8A3D.toInt()))
        heroBg.cornerRadius = dpf(30f)
        hero.background = heroBg
        hero.elevation = dpf(6f)
        hero.setPadding(dp(22), dp(22), dp(8), dp(22))
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.gravity = Gravity.CENTER_VERTICAL
        val ink = 0xFF1A1202.toInt()
        val headline = label("Leitura sem ruído.", 26f, ink, 2)
        headline.setLineSpacing(0f, 0.98f)
        left.addView(headline)
        val sub = label("Abra um PDF, destaque o que importa e continue de onde parou.", 13.5f, ink.withAlpha(0xCC), 0)
        sub.setPadding(0, dp(8), 0, dp(16))
        sub.setLineSpacing(0f, 1.12f)
        left.addView(sub)
        val cta = LinearLayout(this)
        cta.orientation = LinearLayout.HORIZONTAL
        cta.gravity = Gravity.CENTER_VERTICAL
        cta.setPadding(dp(12), 0, dp(18), 0)
        cta.background = ripple(roundBg(0xFF15171C.toInt(), dpf(24f)), Color.WHITE.withAlpha(40), dpf(24f))
        cta.isClickable = true
        cta.setOnClickListener { choosePdf() }
        val plus = IconView(this, "plus", pal.accent)
        plus.sizeRatio = 0.62f
        cta.addView(plus, lp(dp(30), dp(30)))
        cta.addView(label("Abrir PDF", 14.5f, Color.WHITE, 1))
        left.addView(cta, lp(-2, dp(48)))
        hero.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        val art = HeroView(this)
        val alp = lp(dp(112), dp(158))
        alp.gravity = Gravity.CENTER_VERTICAL
        hero.addView(art, alp)
        val hlp = lp(-1, -2)
        hlp.topMargin = dp(14)
        homeList.addView(hero, hlp)

        // recentes
        val list = recents.all()
        val titleRow = LinearLayout(this)
        titleRow.orientation = LinearLayout.HORIZONTAL
        titleRow.gravity = Gravity.CENTER_VERTICAL
        titleRow.addView(label("Continuar lendo", 18f, pal.ink, 1), LinearLayout.LayoutParams(0, -2, 1f))
        if (list.isNotEmpty()) titleRow.addView(label("${list.size}", 13f, pal.muted, 1))
        val trlp = lp(-1, -2)
        trlp.topMargin = dp(30)
        trlp.bottomMargin = dp(6)
        homeList.addView(titleRow, trlp)

        if (list.isEmpty()) {
            val empty = LinearLayout(this)
            empty.orientation = LinearLayout.HORIZONTAL
            empty.gravity = Gravity.CENTER_VERTICAL
            empty.setPadding(dp(16), dp(18), dp(18), dp(18))
            empty.background = roundBg(pal.surface, dpf(20f), pal.outline, 1)
            empty.addView(IconView(this, "file", pal.accentInk), lp(dp(36), dp(36)))
            val t = label("Seus PDFs recentes aparecem aqui, com a página em que você parou.", 13.5f, pal.muted, 0)
            t.setLineSpacing(0f, 1.1f)
            val tlp = LinearLayout.LayoutParams(0, -2, 1f)
            tlp.marginStart = dp(10)
            empty.addView(t, tlp)
            val elp = lp(-1, -2)
            elp.topMargin = dp(6)
            homeList.addView(empty, elp)
        } else {
            for (d in list) {
                val clp = lp(-1, -2)
                clp.topMargin = dp(10)
                homeList.addView(recentCard(d), clp)
            }
        }
        val ver = label("FBPDF · leitor de PDF", 11.5f, pal.muted, 0)
        ver.gravity = Gravity.CENTER
        val vlp = lp(-1, -2)
        vlp.topMargin = dp(28)
        homeList.addView(ver, vlp)
        applyInsets()
    }

    private fun recentCard(d: RecentDoc): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(dp(12), dp(12), dp(6), dp(12))
        card.background = ripple(roundBg(pal.surface, dpf(22f), pal.outline, 1), pal.ink.withAlpha(24), dpf(22f))
        card.isClickable = true
        card.setOnClickListener { openRecent(d) }

        val coverBox = FrameLayout(this)
        coverBox.background = roundBg(pal.surfaceHigh, dpf(12f))
        val cf = coverFile(Uri.parse(d.uri))
        var bmp: Bitmap? = null
        if (cf.exists()) {
            try {
                bmp = BitmapFactory.decodeFile(cf.path)
            } catch (_: Exception) {
            }
        }
        if (bmp != null) {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(bmp)
            iv.background = roundBg(Color.WHITE, dpf(12f))
            iv.outlineProvider = ViewOutlineProvider.BACKGROUND
            iv.clipToOutline = true
            coverBox.addView(iv, FrameLayout.LayoutParams(-1, -1))
        } else {
            val ic = IconView(this, "file", pal.accentInk)
            ic.sizeRatio = 0.4f
            coverBox.addView(ic, FrameLayout.LayoutParams(-1, -1))
        }
        card.addView(coverBox, lp(dp(62), dp(86)))

        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        val nm = label(stripPdf(d.name), 15f, pal.ink, 1)
        nm.maxLines = 2
        nm.ellipsize = TextUtils.TruncateAt.END
        info.addView(nm)
        val meta = label("Página ${d.page + 1} de ${d.pages}  ·  ${ago(d.time)}", 12f, pal.muted, 0)
        meta.setPadding(0, dp(5), 0, 0)
        info.addView(meta)
        val pr = ThinProgress(this, pal.outline, pal.accent)
        pr.rounded = true
        pr.fraction = if (d.pages > 0) (d.page + 1f) / d.pages else 0f
        val prlp = lp(-1, dp(4))
        prlp.topMargin = dp(12)
        info.addView(pr, prlp)
        val ilp = LinearLayout.LayoutParams(0, -2, 1f)
        ilp.marginStart = dp(14)
        ilp.marginEnd = dp(4)
        card.addView(info, ilp)

        val rm = iconBtn("close", "Remover da lista") {
            recents.remove(d.uri)
            coverFile(Uri.parse(d.uri)).delete()
            buildHome()
        }
        rm.sizeRatio = 0.42f
        rm.tint = pal.muted
        card.addView(rm, lp(dp(40), dp(40)))
        return card
    }

    private fun stripPdf(n: String): String = if (n.lowercase().endsWith(".pdf")) n.dropLast(4) else n

    private fun ago(t: Long): String {
        val mins = (System.currentTimeMillis() - t) / 60000
        return when {
            mins < 1 -> "agora"
            mins < 60 -> "há $mins min"
            mins < 60 * 24 -> "há ${mins / 60} h"
            mins < 60 * 48 -> "ontem"
            mins < 60 * 24 * 30 -> "há ${mins / (60 * 24)} dias"
            else -> java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale("pt", "BR")).format(java.util.Date(t))
        }
    }

    private fun showHome(animate: Boolean) {
        buildHome()
        homeScroll.visibility = View.VISIBLE
        homeScroll.scrollTo(0, 0)
        if (animate) {
            homeScroll.alpha = 0f
            homeScroll.animate().alpha(1f).setDuration(240).start()
        } else {
            homeScroll.alpha = 1f
        }
        topBar.visibility = View.GONE
        bottomStack.visibility = View.GONE
    }

    private fun hideHome() {
        if (homeScroll.visibility != View.VISIBLE) return
        chromeVisible = true
        topBar.animate().cancel()
        bottomStack.animate().cancel()
        topBar.alpha = 1f
        topBar.translationY = 0f
        bottomStack.alpha = 1f
        bottomStack.translationY = 0f
        topBar.visibility = View.VISIBLE
        bottomStack.visibility = View.VISIBLE
        updatePageInsets(false)
        homeScroll.animate().alpha(0f).setDuration(200).withEndAction {
            homeScroll.visibility = View.GONE
            homeScroll.alpha = 1f
        }.start()
    }

    private fun openRecent(d: RecentDoc) {
        val ok = openPdf(Uri.parse(d.uri), d.page)
        if (!ok) {
            recents.remove(d.uri)
            buildHome()
        }
    }

    private fun closeToHome() {
        if (pageView.hasMarks()) {
            confirmSheet("Descartar marcações?", "Você tem destaques que ainda não foram salvos no PDF.", "Descartar") { reallyClose() }
        } else {
            reallyClose()
        }
    }

    private fun reallyClose() {
        persistRecent()
        setTool(TOOL_NONE)
        closePdf()
        showHome(true)
    }

    // ------------------------------------------------------------------ ferramentas

    private fun selectColor(color: Int) {
        markColor = color
        for ((v, c) in swatches) {
            val sel = c == color
            val d = GradientDrawable()
            d.shape = GradientDrawable.OVAL
            d.setColor(c)
            d.setStroke(if (sel) dp(3) else 1, if (sel) pal.ink else pal.outline)
            v.background = d
            v.animate().scaleX(if (sel) 1.14f else 1f).scaleY(if (sel) 1.14f else 1f).setDuration(120).start()
        }
        if (::pageView.isInitialized) pageView.setHighlightColor(color)
    }

    private fun setTool(t: Int) {
        tool = t
        penButton.active = t == TOOL_PEN
        eraserButton.active = t == TOOL_ERASER
        pageView.setMarkMode(t == TOOL_PEN)
        pageView.setEraseMode(t == TOOL_ERASER)
        if (t == TOOL_PEN) {
            palette.alpha = 0f
            palette.visibility = View.VISIBLE
            palette.animate().alpha(1f).setDuration(160).start()
            if (!penHintShown) {
                penHintShown = true
                toast("Arraste sobre o texto para destacar")
            }
        } else {
            palette.visibility = View.GONE
        }
        if (t == TOOL_ERASER) toast("Toque em um destaque para apagá-lo")
    }

    private fun toggleTool(t: Int) = setTool(if (tool == t) TOOL_NONE else t)

    private fun toggleNightPage() {
        nightPage = !nightPage
        prefs.edit().putBoolean("night_page", nightPage).apply()
        pageView.setNightPage(nightPage)
    }

    // ------------------------------------------------------------------ sheets

    private fun newSheet(): Sheet = Sheet(this, pal, insetBottom)

    private fun openMenu() {
        val n = bookmarkPages().size
        newSheet()
            .title(stripPdf(currentName), "Página ${currentPage + 1} de $pageCount")
            .row("hash", "Ir para página") { openJumpSheet() }
            .row("bookmark", "Páginas favoritas", if (n > 0) n.toString() else null) { showBookmarks() }
            .row("contrast", "Leitura noturna do documento", if (nightPage) "Ligada" else "Desligada") { toggleNightPage() }
            .row(if (pal.dark) "moon" else "sun", "Aparência do app") { openAppearanceSheet() }
            .row("info", "Informações do documento") { openInfoSheet() }
            .show()
    }

    private fun openAppearanceSheet() {
        val mode = prefs.getInt("theme", 2)
        newSheet()
            .title("Aparência", "Escolha como o FBPDF se apresenta.")
            .row("moon", "Noite", null, mode == 2) { setThemeMode(2) }
            .row("sun", "Papel (claro)", null, mode == 1) { setThemeMode(1) }
            .row("contrast", "Automático (segue o sistema)", null, mode == 0) { setThemeMode(0) }
            .show()
    }

    private fun setThemeMode(m: Int) {
        if (prefs.getInt("theme", 2) == m) return
        prefs.edit().putInt("theme", m).apply()
        recreate()
    }

    private fun infoRow(k: String, v: String): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.addView(label(k, 14f, pal.muted, 0), LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(label(v, 14.5f, pal.ink, 1))
        r.setPadding(0, dp(12), 0, dp(12))
        return r
    }

    private fun openInfoSheet() {
        val s = newSheet().title("Informações")
        s.add(infoRow("Arquivo", stripPdf(currentName)))
        s.add(infoRow("Páginas", pageCount.toString()))
        s.add(infoRow("Página atual", (currentPage + 1).toString()))
        s.add(infoRow("Favoritas", bookmarkPages().size.toString()))
        s.add(infoRow("Destaques não salvos", pageView.getHighlights().size.toString()))
        s.show()
    }

    private fun confirmSheet(title: String, msg: String, positive: String, action: () -> Unit) {
        val s = newSheet().title(title, msg)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val cancel = pillButton(pal, "Cancelar", false) { s.dismiss() }
        val ok = pillButton(pal, positive, true) {
            s.dismiss()
            action()
        }
        val clp = LinearLayout.LayoutParams(0, dp(50), 1f)
        clp.marginEnd = dp(8)
        row.addView(cancel, clp)
        row.addView(ok, LinearLayout.LayoutParams(0, dp(50), 1f))
        s.bottom(row)
        s.show()
    }

    private fun openJumpSheet() {
        if (pageCount < 1) return
        val sheet = newSheet().title("Ir para página", "Digite um número de 1 a $pageCount.")
        val field = inputField(pal, "Página")
        field.inputType = InputType.TYPE_CLASS_NUMBER
        field.imeOptions = EditorInfo.IME_ACTION_GO
        val go = {
            val n = (field.text.toString().toIntOrNull() ?: (currentPage + 1)).coerceIn(1, pageCount)
            sheet.dismiss()
            showPage(n - 1, if (n - 1 > currentPage) 1 else -1)
        }
        field.setOnEditorActionListener { _, _, _ ->
            go()
            true
        }
        sheet.top(field, lp(-1, dp(52)))
        val blp = lp(-1, dp(50))
        blp.topMargin = dp(14)
        sheet.bottom(pillButton(pal, "Ir para a página", true) { go() }, blp)
        field.requestFocus()
        sheet.show(true)
    }

    // ----- pesquisa

    private fun openSearchSheet() {
        if (currentUri == null) return
        val sheet = newSheet().title("Pesquisar no documento")
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val field = inputField(pal, "Palavra ou frase")
        field.imeOptions = EditorInfo.IME_ACTION_SEARCH
        val results = LinearLayout(this)
        results.orientation = LinearLayout.VERTICAL
        val go = { runSearch(field.text.toString().trim(), results, sheet) }
        val goBtn = IconView(this, "search", pal.onAccent)
        goBtn.sizeRatio = 0.5f
        goBtn.isClickable = true
        goBtn.background = ripple(roundBg(pal.accent, dpf(18f)), pal.onAccent.withAlpha(40), dpf(18f))
        goBtn.setOnClickListener { go() }
        field.setOnEditorActionListener { _, _, _ ->
            go()
            true
        }
        row.addView(field, LinearLayout.LayoutParams(0, dp(52), 1f))
        val glp = lp(dp(52), dp(52))
        glp.marginStart = dp(8)
        row.addView(goBtn, glp)
        sheet.top(row)
        sheet.top(View(this), lp(1, dp(10)))
        sheet.add(results)
        sheet.setOnDismiss { searchGen++ }
        field.requestFocus()
        sheet.show(true)
    }

    private fun note(text: String): TextView {
        val t = label(text, 13.5f, pal.muted, 0)
        t.setPadding(dp(4), dp(10), dp(4), dp(10))
        t.setLineSpacing(0f, 1.12f)
        return t
    }

    private fun runSearch(term: String, results: LinearLayout, sheet: Sheet) {
        val uri = currentUri ?: return
        if (term.isEmpty()) return
        val gen = ++searchGen
        results.removeAllViews()
        results.addView(note("Buscando…"))
        Thread {
            val hits = ArrayList<SearchHit>()
            var error: String? = null
            val temp = File(cacheDir, "fbpdf-search-$gen.pdf")
            try {
                contentResolver.openInputStream(uri)?.use { input -> temp.outputStream().use { out -> input.copyTo(out) } }
                PDDocument.load(temp).use { doc ->
                    val stripper = PDFTextStripper()
                    for (i in 0 until doc.numberOfPages) {
                        if (gen != searchGen) return@use
                        stripper.startPage = i + 1
                        stripper.endPage = i + 1
                        val flat = stripper.getText(doc).replace(Regex("\\s+"), " ").trim()
                        val idx = flat.indexOf(term, ignoreCase = true)
                        if (idx >= 0) {
                            var count = 0
                            var from = 0
                            while (true) {
                                val k = flat.indexOf(term, from, ignoreCase = true)
                                if (k < 0) break
                                count++
                                from = k + max(1, term.length)
                            }
                            val s0 = max(0, idx - 34)
                            val e0 = min(flat.length, idx + term.length + 70)
                            val prefix = if (s0 > 0) "…" else ""
                            val suffix = if (e0 < flat.length) "…" else ""
                            hits.add(SearchHit(i, prefix + flat.substring(s0, e0) + suffix, prefix.length + (idx - s0), min(term.length, e0 - idx), count))
                            if (hits.size >= 300) return@use
                        }
                    }
                }
            } catch (e: Exception) {
                error = e.localizedMessage ?: "erro desconhecido"
            } finally {
                temp.delete()
            }
            val err = error
            runOnUiThread {
                if (gen == searchGen) showHits(results, sheet, term, hits, err)
            }
        }.start()
    }

    private fun showHits(results: LinearLayout, sheet: Sheet, term: String, hits: List<SearchHit>, error: String?) {
        results.removeAllViews()
        if (error != null) {
            results.addView(note("Falha na pesquisa: $error"))
            return
        }
        if (hits.isEmpty()) {
            results.addView(note("Nenhuma ocorrência de “$term”.\nSe o PDF for escaneado, ele não tem texto pesquisável."))
            return
        }
        val total = hits.sumOf { it.count }
        results.addView(note("$total ocorrência(s) em ${hits.size} página(s)"))
        for (h in hits) results.addView(hitRow(h, sheet))
    }

    private fun hitRow(h: SearchHit, sheet: Sheet): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(6), dp(10), dp(8), dp(10))
        row.background = ripple(null, pal.ink.withAlpha(26), dpf(16f))
        row.isClickable = true
        row.setOnClickListener {
            sheet.dismiss()
            showPage(h.page, if (h.page > currentPage) 1 else -1)
        }
        val chip = label("p. ${h.page + 1}", 12f, pal.accentInk, 1)
        chip.gravity = Gravity.CENTER
        chip.background = roundBg(pal.accent.withAlpha(if (pal.dark) 40 else 70), dpf(12f))
        chip.setPadding(dp(10), dp(6), dp(10), dp(6))
        row.addView(chip, lp(-2, -2))
        val sp = SpannableString(h.snippet)
        val a = h.start.coerceIn(0, sp.length)
        val b = (h.start + h.len).coerceIn(a, sp.length)
        sp.setSpan(BackgroundColorSpan(pal.accent.withAlpha(if (pal.dark) 110 else 150)), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sp.setSpan(ForegroundColorSpan(pal.ink), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val tv = label(sp, 13.5f, pal.muted, 0)
        tv.setLineSpacing(0f, 1.12f)
        val tlp = LinearLayout.LayoutParams(0, -2, 1f)
        tlp.marginStart = dp(12)
        row.addView(tv, tlp)
        return row
    }

    // ----- miniaturas

    private fun openThumbs() {
        if (pageCount < 1) return
        val bookmarks = bookmarkPages().mapNotNull { it.toIntOrNull() }.toSet()
        val sheet = newSheet().title("Páginas", "$pageCount no total · toque para abrir")
        val gap = dp(10)
        val gridW = resources.displayMetrics.widthPixels - dp(40)
        val cw = (gridW - gap * 2) / 3
        val ch = (cw * 1.38f).toInt()
        val grid = GridView(this)
        grid.numColumns = 3
        grid.horizontalSpacing = gap
        grid.verticalSpacing = gap
        grid.isVerticalScrollBarEnabled = false
        grid.setSelector(ColorDrawable(Color.TRANSPARENT))
        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = pageCount
            override fun getItem(position: Int): Any = position
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val cell = (convertView as? ThumbCell) ?: ThumbCell(this@MainActivity, pal, cw, ch)
                val bmp = thumbCache.get(position)
                cell.bind(position, position == currentPage, bookmarks.contains(position), bmp)
                if (bmp == null) requestThumb(position) { notifyDataSetChanged() }
                return cell
            }
        }
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, position, _ ->
            sheet.dismiss()
            showPage(position, if (position > currentPage) 1 else -1)
        }
        grid.post { grid.setSelection(currentPage) }
        val glp = lp(-1, (resources.displayMetrics.heightPixels * 0.6f).toInt())
        sheet.top(grid, glp)
        sheet.show()
    }

    private fun requestThumb(position: Int, done: () -> Unit) {
        if (!thumbPending.add(position)) return
        val gen = docGen
        thumbExec.execute {
            val b = renderPage(position, 240)
            runOnUiThread {
                thumbPending.remove(position)
                if (b != null) {
                    if (gen == docGen) {
                        thumbCache.put(position, b)
                        done()
                    } else {
                        b.recycle()
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ favoritos

    private fun bookmarkPrefs() = getSharedPreferences("fbpdf_bookmarks", MODE_PRIVATE)
    private fun bookmarkKey() = currentUri?.toString() ?: "none"
    private fun bookmarkPages(): MutableSet<String> = bookmarkPrefs().getStringSet(bookmarkKey(), emptySet())?.toMutableSet() ?: mutableSetOf()
    private fun isBookmarked() = bookmarkPages().contains(currentPage.toString())

    private fun toggleBookmark() {
        if (currentUri == null) return
        val pages = bookmarkPages()
        val added = pages.add(currentPage.toString())
        if (!added) pages.remove(currentPage.toString())
        bookmarkPrefs().edit().putStringSet(bookmarkKey(), pages).apply()
        bookmarkButton.active = added
        bookmarkButton.filled = added
        toast(if (added) "Página favoritada" else "Favorito removido")
    }

    private fun showBookmarks() {
        val pages = bookmarkPages().mapNotNull { it.toIntOrNull() }.sorted()
        if (pages.isEmpty()) {
            toast("Nenhuma página favorita ainda")
            return
        }
        val s = newSheet().title("Páginas favoritas", "${pages.size} marcada(s)")
        for (p in pages) {
            s.row("bookmark", "Página ${p + 1}") { showPage(p, if (p > currentPage) 1 else -1) }
        }
        s.show()
    }

    // ------------------------------------------------------------------ abrir / renderizar

    private fun choosePdf() {
        val pick = Intent(Intent.ACTION_OPEN_DOCUMENT)
        pick.addCategory(Intent.CATEGORY_OPENABLE)
        pick.type = "application/pdf"
        pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(pick, REQUEST_OPEN)
    }

    @Deprecated("Using activity result for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_OPEN && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            } catch (_: SecurityException) {
            }
            openPdf(uri)
        } else if (requestCode == REQUEST_SCREENSHOT && resultCode == RESULT_OK) {
            data?.data?.let { writeScreenshot(it) }
        }
    }

    private fun queryName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Exception) {
        null
    }

    private fun openPdf(uri: Uri, startPage: Int = 0, state: Bundle? = null): Boolean {
        try {
            closePdf()
            val fd = contentResolver.openFileDescriptor(uri, "r") ?: throw IOException("Não foi possível abrir o arquivo")
            val pdf = try {
                PdfRenderer(fd)
            } catch (e: Exception) {
                try {
                    fd.close()
                } catch (_: Exception) {
                }
                throw e
            }
            if (pdf.pageCount < 1) {
                pdf.close()
                fd.close()
                throw IOException("PDF sem páginas")
            }
            synchronized(renderLock) {
                descriptor = fd
                renderer = pdf
            }
            currentUri = uri
            pageCount = pdf.pageCount
            currentName = queryName(uri) ?: "Documento PDF"
            titleView.text = stripPdf(currentName)
            thumbCache.evictAll()
            val first = startPage.coerceIn(0, pageCount - 1)
            setTool(TOOL_NONE)
            hideHome()
            extractTextBoxesAsync(uri, first)
            showPage(first, 0)
            if (state != null) pageView.restoreMarks(state)
            bookmarkButton.active = isBookmarked()
            bookmarkButton.filled = isBookmarked()
            saveButton.badge = pageView.hasMarks()
            persistRecent()
            ensureCover()
            return true
        } catch (e: Throwable) {
            closePdf()
            if (homeScroll.visibility != View.VISIBLE) showHome(false)
            toast("Não foi possível abrir este PDF: ${e.localizedMessage ?: "arquivo inválido ou protegido"}", true)
            return false
        }
    }

    private fun closePdf() {
        docGen++
        pageView.clearPage()
        synchronized(renderLock) {
            try {
                renderer?.close()
            } catch (_: Exception) {
            }
            try {
                descriptor?.close()
            } catch (_: Exception) {
            }
            renderer = null
            descriptor = null
        }
        currentUri = null
        currentPage = 0
        pageCount = 0
        textBoxes.clear()
        thumbPending.clear()
    }

    private fun renderPage(index: Int, targetW: Int): Bitmap? = synchronized(renderLock) {
        val r = renderer ?: return@synchronized null
        if (index < 0 || index >= r.pageCount) return@synchronized null
        r.openPage(index).use { page ->
            val scale = targetW.toFloat() / page.width
            val h = (page.height * scale).toInt().coerceAtLeast(1)
            val b = Bitmap.createBitmap(targetW, h, Bitmap.Config.ARGB_8888)
            b.eraseColor(Color.WHITE)
            page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            b
        }
    }

    private fun showPage(index: Int, dir: Int = 0) {
        if (renderer == null || index < 0 || index >= pageCount) return
        try {
            val maxW = (resources.displayMetrics.widthPixels * 2).coerceAtMost(4096)
            val bmp = renderPage(index, maxW) ?: return
            pageView.setPage(bmp, index, textBoxes[index] ?: emptyList())
            if (dir != 0) {
                pageView.animate().cancel()
                pageView.alpha = 0f
                pageView.translationX = dir * dp(40).toFloat()
                pageView.animate().alpha(1f).translationX(0f).setDuration(210).setInterpolator(DecelerateInterpolator()).start()
            }
            currentPage = index
            updatePageUi()
        } catch (e: Throwable) {
            toast("Erro ao renderizar página: ${e.localizedMessage}")
        }
    }

    private fun updatePageUi() {
        scrubLabel.text = "${currentPage + 1} / $pageCount"
        subtitleView.text = "Página ${currentPage + 1} de $pageCount"
        slider.max = (pageCount - 1).coerceAtLeast(0)
        slider.progress = currentPage
        slider.isEnabled = pageCount > 1
        readProgress.fraction = if (pageCount > 0) (currentPage + 1f) / pageCount else 0f
        val bm = isBookmarked()
        bookmarkButton.active = bm
        bookmarkButton.filled = bm
    }

    private fun persistRecent() {
        val u = currentUri ?: return
        recents.touch(u.toString(), currentName, currentPage, pageCount)
    }

    private fun coverFile(uri: Uri): File = File(File(filesDir, "covers"), "${uri.toString().hashCode()}.jpg")

    private fun ensureCover() {
        val u = currentUri ?: return
        val file = coverFile(u)
        if (file.exists()) return
        thumbExec.execute {
            val b = renderPage(0, 260) ?: return@execute
            try {
                file.parentFile?.mkdirs()
                file.outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 82, it) }
            } catch (_: Exception) {
            }
            b.recycle()
        }
    }

    /** Extrai as caixas de texto em segundo plano; a página atual é priorizada. */
    private fun extractTextBoxesAsync(uri: Uri, startPage: Int) {
        textBoxes.clear()
        val gen = docGen
        textExec.execute {
            val temp = File(cacheDir, "fbpdf-text-$gen.pdf")
            try {
                contentResolver.openInputStream(uri)?.use { input -> temp.outputStream().use { out -> input.copyTo(out) } } ?: return@execute
                PDDocument.load(temp).use { doc ->
                    val n = doc.numberOfPages
                    val order = ArrayList<Int>()
                    for (i in startPage until n) order.add(i)
                    for (i in 0 until startPage) order.add(i)
                    for (i in order) {
                        if (gen != docGen) return@use
                        val box = doc.getPage(i).mediaBox
                        val pw = box.width
                        val ph = box.height
                        val boxes = ArrayList<PdfTextBox>()
                        val stripper = object : PDFTextStripper() {
                            override fun processTextPosition(text: TextPosition) {
                                val l = (text.xDirAdj / pw).coerceIn(0f, 1f)
                                val r = ((text.xDirAdj + text.widthDirAdj) / pw).coerceIn(0f, 1f)
                                val t = ((text.yDirAdj - text.heightDir) / ph).coerceIn(0f, 1f)
                                val b = ((text.yDirAdj + text.heightDir * 0.22f) / ph).coerceIn(0f, 1f)
                                if (r > l && b > t) boxes.add(PdfTextBox(l, t, r, b))
                            }
                        }
                        stripper.startPage = i + 1
                        stripper.endPage = i + 1
                        stripper.getText(doc)
                        runOnUiThread {
                            if (gen == docGen) {
                                textBoxes[i] = boxes
                                if (i == currentPage) pageView.setTextBoxes(boxes)
                            }
                        }
                    }
                }
            } catch (_: Throwable) {
            } finally {
                temp.delete()
            }
        }
    }

    // ------------------------------------------------------------------ salvar / capturar / compartilhar

    private fun captureScreenshot() {
        val u = currentUri ?: return
        pendingScreenshot = pageView.exportPageImage() ?: return
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "image/png"
        intent.putExtra(Intent.EXTRA_TITLE, stripPdf(queryName(u) ?: "pagina") + "-pagina-${currentPage + 1}.png")
        startActivityForResult(intent, REQUEST_SCREENSHOT)
    }

    private fun writeScreenshot(destination: Uri) {
        val bitmap = pendingScreenshot ?: return
        try {
            contentResolver.openOutputStream(destination, "w")?.use { out ->
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) throw IOException("Falha ao gerar a imagem")
            } ?: throw IOException("Não foi possível salvar a captura")
            toast("Captura salva!")
        } catch (e: Exception) {
            toast("Erro ao salvar captura: ${e.localizedMessage}", true)
        } finally {
            bitmap.recycle()
            pendingScreenshot = null
        }
    }

    private fun saveMarkedPdf() {
        val uri = currentUri ?: return
        val highlights = pageView.getHighlights()
        if (highlights.isEmpty()) {
            toast("Destaque algum texto primeiro")
            return
        }
        pendingSaveHighlights = highlights
        writeMarkedPdfInPlace(uri)
    }

    private fun writeMarkedPdfInPlace(source: Uri) {
        val original = File(cacheDir, "fbpdf-original.pdf")
        val updated = File(cacheDir, "fbpdf-updated.pdf")
        val savedPage = currentPage
        val backup = pendingSaveHighlights
        try {
            contentResolver.openInputStream(source)?.use { input -> original.outputStream().use { input.copyTo(it) } }
                ?: throw IOException("Não foi possível ler o PDF")
            PDDocument.load(original).use { document ->
                pendingSaveHighlights.forEach { mark ->
                    if (mark.page !in 0 until document.numberOfPages) return@forEach
                    val page = document.getPage(mark.page)
                    val box = page.mediaBox
                    val x1 = mark.left * box.width
                    val x2 = mark.right * box.width
                    val top = (1f - mark.top) * box.height
                    val bottom = (1f - mark.bottom) * box.height
                    val annotation = PDAnnotationTextMarkup(PDAnnotationTextMarkup.SUB_TYPE_HIGHLIGHT)
                    annotation.rectangle = PDRectangle(x1, bottom, (x2 - x1).coerceAtLeast(1f), (top - bottom).coerceAtLeast(1f))
                    annotation.quadPoints = floatArrayOf(x1, top, x2, top, x1, bottom, x2, bottom)
                    annotation.color = PDColor(
                        floatArrayOf(Color.red(mark.color) / 255f, Color.green(mark.color) / 255f, Color.blue(mark.color) / 255f),
                        PDDeviceRGB.INSTANCE
                    )
                    annotation.constantOpacity = 0.32f
                    page.annotations.add(annotation)
                }
                updated.outputStream().use { document.save(it) }
            }
            closePdf()
            contentResolver.openOutputStream(source, "wt")?.use { output -> updated.inputStream().use { it.copyTo(output) } }
                ?: throw IOException("O local do arquivo não permite sobrescrever o PDF")
            pendingSaveHighlights = emptyList()
            coverFile(source).delete()
            openPdf(source, savedPage)
            toast("PDF atualizado com os seus destaques!", true)
        } catch (e: Exception) {
            toast("Não foi possível atualizar este arquivo. Talvez ele seja somente leitura: ${e.localizedMessage}", true)
            if (currentUri == null) {
                if (openPdf(source, savedPage)) pageView.setMarks(backup)
            }
        } finally {
            original.delete()
            updated.delete()
            pendingSaveHighlights = emptyList()
        }
    }

    private fun sharePdf() {
        val uri = currentUri ?: return
        val send = Intent(Intent.ACTION_SEND)
        send.type = "application/pdf"
        send.putExtra(Intent.EXTRA_STREAM, uri)
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(send, "Compartilhar PDF"))
    }

    private fun toast(msg: String, long: Boolean = false) {
        Toast.makeText(this, msg, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val TOOL_NONE = 0
        private const val TOOL_PEN = 1
        private const val TOOL_ERASER = 2
        private const val REQUEST_OPEN = 1001
        private const val REQUEST_SCREENSHOT = 1003
        private const val DOCK_H = 60
        private const val SCRUB_H = 46
        private const val GAP = 8
    }
}
