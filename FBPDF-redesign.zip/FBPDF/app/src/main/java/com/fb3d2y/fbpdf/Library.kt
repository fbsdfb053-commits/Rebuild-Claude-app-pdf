package com.fb3d2y.fbpdf

import android.content.Context
import android.graphics.Bitmap
import android.view.Gravity
import android.view.View
import android.widget.AbsListView
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

data class RecentDoc(val uri: String, val name: String, val page: Int, val pages: Int, val time: Long)

/** Biblioteca: últimos documentos abertos, com a página onde você parou. */
class RecentStore(context: Context) {
    private val prefs = context.getSharedPreferences("fbpdf_recents", Context.MODE_PRIVATE)

    fun all(): List<RecentDoc> {
        val raw = prefs.getString("items", null) ?: return emptyList()
        val out = ArrayList<RecentDoc>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(RecentDoc(o.getString("uri"), o.optString("name", "Documento"), o.optInt("page", 0), o.optInt("pages", 1), o.optLong("time", 0L)))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun save(list: List<RecentDoc>) {
        val arr = JSONArray()
        for (d in list) {
            val o = JSONObject()
            o.put("uri", d.uri)
            o.put("name", d.name)
            o.put("page", d.page)
            o.put("pages", d.pages)
            o.put("time", d.time)
            arr.put(o)
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }

    fun touch(uri: String, name: String, page: Int, pages: Int) {
        val list = all().filter { it.uri != uri }.toMutableList()
        list.add(0, RecentDoc(uri, name, page, pages, System.currentTimeMillis()))
        save(list.take(30))
    }

    fun remove(uri: String) {
        save(all().filter { it.uri != uri })
    }
}

/** Célula da grade de miniaturas das páginas. */
class ThumbCell(context: Context, private val pal: Palette, cw: Int, ch: Int) : FrameLayout(context) {
    private val image = ImageView(context)
    private val num: TextView = context.label("", 11.5f, pal.muted, 1)
    private val mark = IconView(context, "bookmark", pal.accentInk)

    init {
        layoutParams = AbsListView.LayoutParams(cw, ch)
        image.scaleType = ImageView.ScaleType.FIT_CENTER
        image.setPadding(context.dp(7), context.dp(7), context.dp(7), context.dp(25))
        addView(image, LayoutParams(-1, -1))
        val nlp = LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        nlp.bottomMargin = context.dp(7)
        addView(num, nlp)
        mark.filled = true
        mark.sizeRatio = 0.7f
        addView(mark, LayoutParams(context.dp(26), context.dp(30), Gravity.TOP or Gravity.END))
    }

    fun bind(p: Int, current: Boolean, bookmarked: Boolean, bmp: Bitmap?) {
        background = roundBg(pal.surfaceHigh, context.dpf(14f), if (current) pal.accent else pal.outline, if (current) context.dp(2) else 1)
        num.text = (p + 1).toString()
        num.setTextColor(if (current) pal.accentInk else pal.muted)
        mark.visibility = if (bookmarked) View.VISIBLE else View.GONE
        image.setImageBitmap(bmp)
    }
}
