package com.fb3d2y.fbpdf

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Ícone desenhado em Canvas (grade 24x24, traço arredondado).
 * Serve como ícone estático ou como botão (isClickable = true).
 */
class IconView(
    context: Context,
    var name: String,
    var tint: Int,
    private val activeBg: Int = 0,
    private val activeInk: Int = 0,
    private val dotColor: Int = 0
) : View(context) {

    var active: Boolean = false
        set(value) {
            field = value
            invalidate()
        }
    var filled: Boolean = false
        set(value) {
            field = value
            invalidate()
        }
    var badge: Boolean = false
        set(value) {
            field = value
            invalidate()
        }
    var sizeRatio: Float = 0.54f

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.9f
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        alpha = if (enabled) 1f else 0.34f
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (isClickable && isEnabled) {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> animate().scaleX(0.9f).scaleY(0.9f).setDuration(70).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> animate().scaleX(1f).scaleY(1f).setDuration(150).start()
            }
        }
        return super.onTouchEvent(event)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (active && activeBg != 0) {
            bgPaint.color = activeBg
            val r = context.dpf(18f)
            canvas.drawRoundRect(w * 0.14f, h * 0.12f, w * 0.86f, h * 0.88f, r, r, bgPaint)
        }
        val color = if (active && activeInk != 0) activeInk else tint
        stroke.color = color
        fill.color = color
        val u = min(w, h) * sizeRatio / 24f
        canvas.save()
        canvas.translate((w - 24f * u) / 2f, (h - 24f * u) / 2f)
        canvas.scale(u, u)
        Icons.draw(canvas, name, stroke, fill, filled)
        canvas.restore()
        if (badge && dotColor != 0) {
            bgPaint.color = dotColor
            canvas.drawCircle(w * 0.70f, h * 0.27f, context.dpf(4.2f), bgPaint)
        }
    }
}

object Icons {
    fun draw(c: Canvas, name: String, s: Paint, f: Paint, filled: Boolean) {
        val p = Path()
        when (name) {
            "folder" -> {
                p.moveTo(3f, 18f); p.lineTo(3f, 6.5f); p.quadTo(3f, 5f, 4.5f, 5f)
                p.lineTo(9f, 5f); p.lineTo(11f, 7.5f); p.lineTo(19.5f, 7.5f)
                p.quadTo(21f, 7.5f, 21f, 9f); p.lineTo(21f, 18f)
                p.quadTo(21f, 19.5f, 19.5f, 19.5f); p.lineTo(4.5f, 19.5f)
                p.quadTo(3f, 19.5f, 3f, 18f); p.close()
                c.drawPath(p, s)
            }
            "plus" -> {
                c.drawLine(12f, 5f, 12f, 19f, s)
                c.drawLine(5f, 12f, 19f, 12f, s)
            }
            "search" -> {
                c.drawCircle(10.5f, 10.5f, 6.5f, s)
                c.drawLine(15.3f, 15.3f, 20.5f, 20.5f, s)
            }
            "more" -> {
                c.drawCircle(12f, 5.5f, 1.7f, f)
                c.drawCircle(12f, 12f, 1.7f, f)
                c.drawCircle(12f, 18.5f, 1.7f, f)
            }
            "back" -> {
                c.drawLine(19f, 12f, 5f, 12f, s)
                p.moveTo(11f, 6f); p.lineTo(5f, 12f); p.lineTo(11f, 18f)
                c.drawPath(p, s)
            }
            "pen" -> {
                c.save()
                c.rotate(45f, 12f, 12f)
                c.drawRoundRect(9.2f, 2.2f, 14.8f, 15f, 1.4f, 1.4f, s)
                p.moveTo(9.2f, 15f); p.lineTo(12f, 21.5f); p.lineTo(14.8f, 15f)
                c.drawPath(p, s)
                c.drawLine(9.2f, 6.5f, 14.8f, 6.5f, s)
                c.restore()
                c.drawLine(3.5f, 21.5f, 9f, 21.5f, s)
            }
            "eraser" -> {
                c.save()
                c.rotate(-45f, 12f, 12f)
                c.drawRoundRect(3.5f, 8f, 20.5f, 16f, 2.4f, 2.4f, s)
                c.drawLine(11f, 8f, 11f, 16f, s)
                c.restore()
                c.drawLine(13f, 21.8f, 21f, 21.8f, s)
            }
            "bookmark" -> {
                p.moveTo(6.5f, 3.5f); p.lineTo(17.5f, 3.5f); p.lineTo(17.5f, 20.5f)
                p.lineTo(12f, 16.5f); p.lineTo(6.5f, 20.5f); p.close()
                if (filled) c.drawPath(p, f)
                c.drawPath(p, s)
            }
            "save" -> {
                c.drawLine(12f, 4f, 12f, 15f, s)
                p.moveTo(7.5f, 10.5f); p.lineTo(12f, 15f); p.lineTo(16.5f, 10.5f)
                c.drawPath(p, s)
                p.reset()
                p.moveTo(4f, 16f); p.lineTo(4f, 19f); p.quadTo(4f, 20.5f, 5.5f, 20.5f)
                p.lineTo(18.5f, 20.5f); p.quadTo(20f, 20.5f, 20f, 19f); p.lineTo(20f, 16f)
                c.drawPath(p, s)
            }
            "camera" -> {
                c.drawRoundRect(2.5f, 7f, 21.5f, 20f, 3f, 3f, s)
                p.moveTo(7.5f, 7f); p.lineTo(9.2f, 4.5f); p.lineTo(14.8f, 4.5f); p.lineTo(16.5f, 7f)
                c.drawPath(p, s)
                c.drawCircle(12f, 13.5f, 3.6f, s)
            }
            "share" -> {
                c.drawCircle(6f, 12f, 2.6f, s)
                c.drawCircle(18f, 5.5f, 2.6f, s)
                c.drawCircle(18f, 18.5f, 2.6f, s)
                c.drawLine(8.3f, 10.8f, 15.7f, 6.7f, s)
                c.drawLine(8.3f, 13.2f, 15.7f, 17.3f, s)
            }
            "chevL" -> {
                p.moveTo(14.5f, 5f); p.lineTo(7.5f, 12f); p.lineTo(14.5f, 19f)
                c.drawPath(p, s)
            }
            "chevR" -> {
                p.moveTo(9.5f, 5f); p.lineTo(16.5f, 12f); p.lineTo(9.5f, 19f)
                c.drawPath(p, s)
            }
            "close" -> {
                c.drawLine(6f, 6f, 18f, 18f, s)
                c.drawLine(18f, 6f, 6f, 18f, s)
            }
            "check" -> {
                p.moveTo(5f, 12.5f); p.lineTo(10f, 17.5f); p.lineTo(19f, 7f)
                c.drawPath(p, s)
            }
            "grid" -> {
                c.drawRoundRect(3.5f, 3.5f, 10.5f, 10.5f, 1.8f, 1.8f, s)
                c.drawRoundRect(13.5f, 3.5f, 20.5f, 10.5f, 1.8f, 1.8f, s)
                c.drawRoundRect(3.5f, 13.5f, 10.5f, 20.5f, 1.8f, 1.8f, s)
                c.drawRoundRect(13.5f, 13.5f, 20.5f, 20.5f, 1.8f, 1.8f, s)
            }
            "moon" -> {
                p.moveTo(20.5f, 14.2f)
                p.cubicTo(19.3f, 14.8f, 17.9f, 15.1f, 16.5f, 15.1f)
                p.cubicTo(11.8f, 15.1f, 8.1f, 11.4f, 8.1f, 6.7f)
                p.cubicTo(8.1f, 5.3f, 8.4f, 4f, 9f, 2.8f)
                p.cubicTo(5.4f, 4f, 3f, 7.4f, 3f, 11.3f)
                p.cubicTo(3f, 16.4f, 7.1f, 20.5f, 12.2f, 20.5f)
                p.cubicTo(16.1f, 20.5f, 19.4f, 18.1f, 20.5f, 14.2f)
                p.close()
                c.drawPath(p, s)
            }
            "sun" -> {
                c.drawCircle(12f, 12f, 4f, s)
                for (i in 0 until 8) {
                    val a = i * PI / 4.0
                    val x1 = 12f + (7f * cos(a)).toFloat()
                    val y1 = 12f + (7f * sin(a)).toFloat()
                    val x2 = 12f + (9.6f * cos(a)).toFloat()
                    val y2 = 12f + (9.6f * sin(a)).toFloat()
                    c.drawLine(x1, y1, x2, y2, s)
                }
            }
            "contrast" -> {
                c.drawCircle(12f, 12f, 9f, s)
                c.drawArc(3f, 3f, 21f, 21f, 90f, 180f, true, f)
            }
            "info" -> {
                c.drawCircle(12f, 12f, 9f, s)
                c.drawLine(12f, 11f, 12f, 16.5f, s)
                c.drawCircle(12f, 7.9f, 1.1f, f)
            }
            "hash" -> {
                c.drawLine(9f, 4f, 7.5f, 20f, s)
                c.drawLine(16.5f, 4f, 15f, 20f, s)
                c.drawLine(4.5f, 9f, 20f, 9f, s)
                c.drawLine(4f, 15f, 19.5f, 15f, s)
            }
            "file" -> {
                p.moveTo(5.5f, 3f); p.lineTo(14f, 3f); p.lineTo(18.5f, 7.5f)
                p.lineTo(18.5f, 21f); p.lineTo(5.5f, 21f); p.close()
                c.drawPath(p, s)
                p.reset()
                p.moveTo(14f, 3f); p.lineTo(14f, 7.5f); p.lineTo(18.5f, 7.5f)
                c.drawPath(p, s)
                c.drawLine(8.5f, 13f, 15.5f, 13f, s)
                c.drawLine(8.5f, 16.5f, 13f, 16.5f, s)
            }
        }
    }
}
