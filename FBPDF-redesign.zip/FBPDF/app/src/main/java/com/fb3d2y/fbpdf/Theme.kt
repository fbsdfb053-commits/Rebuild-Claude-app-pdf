package com.fb3d2y.fbpdf

/** Paleta do app: "Noite" (padrão) e "Papel". O destaque âmbar é a assinatura visual. */
class Palette(
    val dark: Boolean,
    val bg: Int,
    val surface: Int,
    val surfaceHigh: Int,
    val outline: Int,
    val ink: Int,
    val muted: Int,
    val accent: Int,
    val onAccent: Int,
    val accentInk: Int
)

object Themes {
    val night = Palette(
        dark = true,
        bg = 0xFF0B0D11.toInt(),
        surface = 0xFF151922.toInt(),
        surfaceHigh = 0xFF1E2430.toInt(),
        outline = 0xFF2B3240.toInt(),
        ink = 0xFFEDEFF4.toInt(),
        muted = 0xFF8B94A6.toInt(),
        accent = 0xFFFFB84A.toInt(),
        onAccent = 0xFF1A1202.toInt(),
        accentInk = 0xFFFFC266.toInt()
    )

    val day = Palette(
        dark = false,
        bg = 0xFFF3EFE8.toInt(),
        surface = 0xFFFFFFFF.toInt(),
        surfaceHigh = 0xFFF7F3EC.toInt(),
        outline = 0xFFE3DDD0.toInt(),
        ink = 0xFF1A1D24.toInt(),
        muted = 0xFF7A7F8C.toInt(),
        accent = 0xFFFFB84A.toInt(),
        onAccent = 0xFF1A1202.toInt(),
        accentInk = 0xFFB36200.toInt()
    )

    /** Cores de marca-texto. */
    val highlightColors = intArrayOf(
        0xFFFFE45C.toInt(), 0xFF6EE7A8.toInt(), 0xFF6CB6FF.toInt(), 0xFFFF7EB6.toInt(),
        0xFFFFA94D.toInt(), 0xFFB794F6.toInt(), 0xFFFF6B6B.toInt(), 0xFF4FD1D9.toInt()
    )
}
